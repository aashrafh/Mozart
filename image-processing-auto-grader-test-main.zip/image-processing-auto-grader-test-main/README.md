# image-processing-auto-grader-test
Test submission for Image Processing Auto Grader Semester

## Works for SEM only
## Works with google drive public zip files ONLY

# How to use:
- Fork this repo
- Change SUBMISSION_DOWNLOAD_LINK environment variable with yours
- Do not forget to make the link public and any one can view
- Commit and Push
- It will download your submission and test it with auto grader against [public test](https://drive.google.com/file/d/19Q0H_ptIdAvEbFzgfRRJV312lVoBjfRL)
- If all is good you will get green success mark

## Notes :
- In The end of `Run autograder` step logs, you will find all console outputs by your submission
